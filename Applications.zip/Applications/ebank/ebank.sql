-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema banque
--

CREATE DATABASE IF NOT EXISTS banque;
USE banque;

--
-- Definition of table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nom` varchar(45) collate latin1_general_ci NOT NULL,
  `prenom` varchar(45) collate latin1_general_ci NOT NULL,
  `adresse` varchar(45) collate latin1_general_ci NOT NULL,
  `codePostal` varchar(45) collate latin1_general_ci NOT NULL,
  `ville` varchar(45) collate latin1_general_ci NOT NULL,
  `webPassword` varchar(45) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `client`
--

/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` (`id`,`nom`,`prenom`,`adresse`,`codePostal`,`ville`,`webPassword`) VALUES 
 (1,'DUPONT','Robert','40 rue de la Paix','44000','NANTES','password');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;


--
-- Definition of table `compte`
--

DROP TABLE IF EXISTS `compte`;
CREATE TABLE `compte` (
  `numero` int(10) unsigned NOT NULL auto_increment,
  `solde` decimal(10,2) NOT NULL,
  `idClient` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`numero`),
  KEY `FK_compte_1` (`idClient`),
  CONSTRAINT `FK_compte_1` FOREIGN KEY (`idClient`) REFERENCES `client` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `compte`
--

/*!40000 ALTER TABLE `compte` DISABLE KEYS */;
INSERT INTO `compte` (`numero`,`solde`,`idClient`) VALUES 
 (1,'6906.00',1),
 (2,'17784.90',1);
/*!40000 ALTER TABLE `compte` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
